package com.premium.stc.service;

public interface UserService {

}
