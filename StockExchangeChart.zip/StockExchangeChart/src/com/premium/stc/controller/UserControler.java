package com.premium.stc.controller;

public interface UserControler {

}
